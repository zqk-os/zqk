# Bucketing Strategy Backend Support

## Overview

Bucketing strategies support multiple storage backends, allowing strategies to be stored and retrieved from various systems:

- **File-based (YAML)**: Default backend, stores strategies as YAML files in `docs/process/bucketing_strategies/`
- **Graph databases**: Memgraph, Neo4j (via `GraphObjectStorage`)
- **RDF stores**: Jena, AllegroGraph, Neptune (via graph provider abstraction)
- **JSON-LD**: Can be used as a serialization format for any backend

## Architecture

### Storage Abstraction

The system uses a `BucketStrategyStorageProvider` interface to abstract backend differences:

```go
type BucketStrategyStorageProvider interface {
    LoadStrategy(ctx context.Context, strategyID string) (map[string]any, error)
    LoadAllStrategies(ctx context.Context) ([]map[string]any, error)
    LoadStrategiesForKind(ctx context.Context, kind string) ([]map[string]any, error)
    SaveStrategy(ctx context.Context, strategy map[string]any) error
    DeleteStrategy(ctx context.Context, strategyID string) error
    GetBackendType() string
}
```

### Backend Detection

The `BucketStrategyStorageFactory` automatically detects the backend by checking:

1. **Graph backend**: If `ZQK_GRAPH_ENABLED=true` and connection succeeds
2. **File backend**: Default fallback

This matches the same detection logic used by `StorageFactory` for object storage.

### Implementations

#### FileBucketStrategyStorage

- Reads/writes YAML files from `docs/process/bucketing_strategies/`
- Uses `ObjectStorageProvider` to leverage existing file storage infrastructure
- Supports all standard object operations (create, update, delete, list)

#### GraphBucketStrategyStorage

- Stores strategies as nodes in the graph database
- Uses `GraphObjectStorage` which supports:
  - Memgraph (via Bolt protocol)
  - Neo4j (via Bolt protocol)
  - Any graph database with a `GraphProvider` implementation

### RDF/JSON-LD Support

RDF stores (Jena, AllegroGraph, Neptune) are supported via the graph provider abstraction:

- **Jena**: Can be accessed via SPARQL queries through a custom `GraphProvider`
- **AllegroGraph**: Supports SPARQL and can be integrated via `GraphProvider`
- **Neptune**: AWS Neptune supports Gremlin and SPARQL, can be integrated via `GraphProvider`

JSON-LD can be used as a serialization format:
- Strategies stored in graph databases can be exported/imported as JSON-LD
- File-based strategies can be converted to JSON-LD for RDF stores
- The `ObjectStorageProvider` interface handles serialization automatically

## Usage

### Loading Strategies

```go
// Automatic backend detection
loader, err := storage.GetGlobalStrategyLoader(ctx, projectRoot)
if err != nil {
    return err
}

// Load strategies for a specific object kind
strategies, err := loader.GetStrategiesForKind(ctx, "audit_event")
if err != nil {
    return err
}

// Backend type is transparent
backendType := loader.GetBackendType() // "file" or "graph"
```

### Backend-Specific Operations

The loader automatically uses the correct backend based on system configuration. No code changes are needed when switching backends.

## Future Enhancements

1. **Direct RDF Provider**: Native RDF store provider (not via graph abstraction)
2. **JSON-LD Serialization**: Explicit JSON-LD import/export for strategies
3. **Multi-Backend Sync**: Sync strategies across multiple backends
4. **Backend-Specific Optimizations**: Query optimizations for each backend type

