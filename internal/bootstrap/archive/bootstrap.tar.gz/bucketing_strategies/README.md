# Bucketing Strategy Specifications

## Overview

Bucketing strategies define how high-volume objects are organized into buckets (subdirectories) for efficient storage and retrieval. Multiple strategies can be active concurrently for the same object kind.

## Strategy Types

### 1. Chronological (Time-based)
- **Monthly**: `YYYY-MM` (e.g., `2026-01`)
- **Daily**: `YYYY-MM-DD` (e.g., `2026-01-15`)
- **Yearly**: `YYYY` (e.g., `2026`)

### 2. State-based
- Bucket by status/state field (e.g., `active`, `archived`, `pending`)

### 3. Size-based
- Bucket by size ranges (e.g., `small`, `medium`, `large`)

### 4. Composite
- Combine multiple strategies (e.g., `chrono + state`)

## Spec Structure

Strategies are defined in YAML files following the object spec pattern:

```yaml
ontology: bucketing_strategy
kind: bucketing_strategy
schema_version: "2.0.0"
strategy_type: chronological_monthly
field: created_at
format: "2006-01"  # Go time format
enabled: true
applies_to:
  - audit_event
  - change_journal_entry
```

## Location

Strategy specs should be in:
- `docs/process/_internal/bucketing_strategies/`

## Loader Pattern

Follow the `SpecLoader` pattern:
- `BucketStrategyLoader` loads strategy specs
- Caches loaded strategies
- Supports inheritance/composition
- Global loader instance for shared cache

