# Kind-Based Bucketing Strategies

## Overview

All system objects **must** have a bucketing strategy defined. The system ensures this through a hierarchical approach:

1. **Base Strategy**: Kind-based (e.g., `decision`, `audit_event`)
2. **Sub-Kind Strategy**: Sub-kind-based (e.g., `adr` → `decision`, `arch_decision_record` → `decision`)

## Architecture

### DefaultBucketStrategyRegistry

The `DefaultBucketStrategyRegistry` ensures that:
- Every discovered object kind has a strategy (explicit or default)
- Sub-kinds inherit from base kinds via `KindSynonymResolver`
- High-volume kinds get chronological bucketing by default
- Other kinds get path-based (no bucketing) by default

### Strategy Resolution Order

1. **Explicit Strategy**: Check if a `bucketing_strategy` object exists for the kind
2. **Sub-Kind Resolution**: If kind is a sub-kind (e.g., `adr`), resolve to base kind (`decision`)
3. **Default Strategy**: Use kind-appropriate default (chronological for high-volume, path-based for others)

### Sub-Kind Support

Sub-kinds are resolved using `KindSynonymResolver`:
- `adr` → `decision`
- `arch_decision_record` → `decision`
- `architectural_decision` → `decision`

The resolver uses `kind_synonym` objects stored in the system, allowing dynamic sub-kind definitions.

## High-Volume Kinds

These kinds automatically get monthly chronological bucketing:

- `audit_event`
- `change_journal_entry`
- `base_metric`
- `command_metric`
- `scheduler_health_metric`
- `file_lock_metric`
- `audit_aggregation_metric`

## Default Strategies

### Chronological (High-Volume)
- **Field**: `created_at`
- **Format**: `2006-01` (monthly)
- **Use Case**: Time-series data that benefits from temporal organization

### Path-Based (Default)
- **No bucketing**: Objects stored in base directory
- **Use Case**: Low-volume objects, organizational objects, configuration objects

## System Initialization

During system startup, `EnsureAllKindsHaveStrategies()` is called to:
1. Discover all object kinds via `DynamicKindMapper.GetAllKinds()`
2. Ensure each kind has a strategy (explicit or default)
3. Log strategy assignments for monitoring

## Example: Decision → ADR

```yaml
# Base kind: decision
# Sub-kind: adr (via kind_synonym object)

# Strategy for decision (base kind)
id: BST-003
kind: bucketing_strategy
strategy_type: state
strategy_name: status_based
field: status
enabled: true
applies_to:
  - decision

# ADR (sub-kind) automatically inherits decision's strategy
# No separate strategy needed for adr
```

## Integration Points

1. **Hash Registry Pool**: Uses strategies to determine bucket paths
2. **Object Storage**: Applies strategies when creating/updating objects
3. **System Check**: Validates that all kinds have strategies

## Future Enhancements

1. **Strategy Inheritance**: Sub-kinds can override base kind strategies
2. **Composite Strategies**: Multiple strategies per kind (e.g., chrono + state)
3. **Dynamic Strategy Updates**: Hot-reload strategies without restart

