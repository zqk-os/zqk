# Archive Strategy Extension for Bucketing Strategy

## Design Proposal

### Option 1: Extend bucketing_strategy spec (RECOMMENDED)

Add optional archive fields to `bucketing_strategy.yaml`:

```yaml
# Optional archive configuration
archive_strategy:
  enabled: false
  archive_after: "720h"  # Duration before archiving (e.g., "720h" = 30 days)
  archive_tier: "warm"   # Initial archive tier: warm, cold, iced
  compression: false      # Compress archived objects
  encryption: false       # Encrypt archived objects
  
  # Multi-tier progression (optional, for complex scenarios)
  tier_progression:
    - tier: warm
      duration: "720h"    # Keep in warm for 30 days
      location: "archive/warm"
    - tier: cold
      duration: "8760h"   # Move to cold after 1 year
      location: "archive/cold"
      compression: true
    - tier: iced
      duration: "0"        # Keep indefinitely
      location: "archive/iced"
      compression: true
      encryption: true
```

**Pros**:
- Keeps related concerns together
- Simple cases only need `archive_after` and `archive_tier`
- Complex cases can use `tier_progression`
- Reuses existing bucketing infrastructure

**Cons**:
- Makes bucketing_strategy spec more complex
- Archive concerns mixed with active storage concerns

### Option 2: Separate archive_strategy spec

Create new `archive_strategy.yaml` spec that references bucketing strategies:

```yaml
kind: archive_strategy
extends: auditable
fields:
  bucketing_strategy_ref: BST-001  # Reference to bucketing strategy
  archive_after: "720h"
  archive_tier: "warm"
  # ... tier progression
```

**Pros**:
- Separation of concerns
- Can have multiple archive strategies per bucketing strategy
- Cleaner bucketing_strategy spec

**Cons**:
- More complexity (two specs to manage)
- Potential for inconsistency
- More code to maintain

## Recommendation

**Extend bucketing_strategy spec** with optional archive fields. This approach:
1. Keeps related storage organization logic together
2. Allows simple cases (just `archive_after`) without complexity
3. Supports complex multi-tier scenarios via `tier_progression`
4. Maintains consistency with existing bucketing pattern

## Implementation Plan

1. Add optional `archive_strategy` section to `bucketing_strategy.yaml`
2. Make all archive fields optional (default: no archiving)
3. Support simple single-tier archival
4. Support complex multi-tier progression
5. Create scheduler job type for archive operations
6. Integrate with existing aggregation jobs (SCH-002, SCH-003)

