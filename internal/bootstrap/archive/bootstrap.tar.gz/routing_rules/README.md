# Routing Rules

Routing rules define how scheduler job execution events are routed to external systems (webhooks, commands, events, etc.).

## Location

Routing rules are loaded from YAML files in this directory (`docs/process/_internal/routing_rules/`).

## File Format

Each YAML file can contain one or more routing rules:

```yaml
- name: rule_name
  description: Optional description
  enabled: true
  priority: 100  # Higher priority rules are evaluated first
  match:
    event_type: scheduler_job_completed  # Event type to match
    source: scheduler                     # Source filter
    job_id: SCH-001                      # Specific job ID (optional)
    job_category: maintenance            # Job category filter (optional)
    job_type: cache_prewarm              # Job type filter (optional)
    severity: high                       # Severity filter (optional)
    conditions:                          # Complex field-based conditions (optional)
      - field: duration
        operator: gt
        value: 300
  actions:
    - protocol: webhook                  # Protocol: webhook, command, or event
      target: https://example.com/webhook
      method: POST
      timeout_ms: 5000
      retry:
        max_attempts: 3
        backoff_ms: 1000
      auth:
        type: bearer
        token: ${WEBHOOK_TOKEN}
```

## Match Criteria

### Event Types

Common event types:
- `scheduler_job_completed` - Job completed successfully
- `scheduler_job_failed` - Job failed
- `scheduler_job_status` - Job status update
- `scheduler_job_started` - Job started execution

### Source

Always use `scheduler` for scheduler job events.

### Job Filters

- `job_id` - Match specific job ID (e.g., "SCH-001")
- `job_category` - Match job category (e.g., "maintenance", "monitoring")
- `job_type` - Match job type (e.g., "run_wrapper", "cache_prewarm")

### Severity

- `high` - Critical failures, errors
- `medium` - Warnings, important events
- `low` - Informational events

### Conditions

Complex field-based matching:

```yaml
conditions:
  - field: duration          # Field path in payload
    operator: gt            # gt, lt, gte, lte, eq, ne, contains, regex, in
    value: 300              # Comparison value
  - field: metadata.job_id
    operator: eq
    value: SCH-001
```

## Actions

### Webhook Action

```yaml
- protocol: webhook
  target: https://example.com/webhook
  method: POST              # GET, POST, PUT, DELETE
  timeout_ms: 5000
  headers:                  # Optional custom headers
    X-Custom-Header: value
  retry:
    max_attempts: 3
    backoff_ms: 1000
  auth:
    type: bearer            # bearer, basic, api_key, oauth2
    token: ${WEBHOOK_TOKEN}
```

### Command Action

```yaml
- protocol: command
  target: logger            # Command name
  args:                     # Command arguments
    - --level
    - info
    - --format
    - json
  timeout_ms: 2000
  working_dir: /tmp         # Optional working directory
```

### Event Action

```yaml
- protocol: event
  target: cache_monitoring
  transform:                # Optional payload transformation
    add_fields:
      monitored: true
      cache_type: ${payload.job_type}
```

## Environment Variables

You can use environment variables in rule configuration:

```yaml
target: ${ERROR_WEBHOOK_URL}
token: ${ERROR_WEBHOOK_TOKEN}
```

## Priority

Rules are evaluated in priority order (higher priority first). If multiple rules match, all matching rules' actions are executed.

## Examples

See `default_rules.yaml` for example routing rules.

## Disabling Rules

Set `enabled: false` to disable a rule without deleting it:

```yaml
- name: route_job_completions
  enabled: false  # Disabled - won't route
  ...
```

## Validation

Rules are automatically validated when loaded:
- Invalid rules are logged but don't prevent loading (best-effort)
- Validation checks: rule names, priorities, action protocols, URLs, conditions
- See [ROUTER_VALIDATION.md](../../system-health/ROUTER_VALIDATION.md) for details

## Metrics

Router metrics track routing performance:
- Message routing counts (routed, matched, failed, dropped)
- Rule evaluation counts
- Action execution success/failure rates
- Queue depth and capacity
- Per-adapter metrics
- See [ROUTER_METRICS.md](../../system-health/ROUTER_METRICS.md) for details

## Verification

Message delivery verification (optional):
- Register messages for verification
- Track delivery to expected endpoints
- Timeout handling for unresponsive endpoints
- See test I/O job documentation for verification usage

## Best Practices

1. **Start with disabled rules** - Create rules with `enabled: false` and enable them after testing
2. **Use environment variables** - Store sensitive values (tokens, URLs) in environment variables
3. **Set appropriate timeouts** - Use reasonable timeouts to avoid blocking
4. **Configure retries** - Use retry configuration for unreliable endpoints
5. **Use priorities** - Higher priority for critical alerts, lower for logging
6. **Test rules** - Test routing rules in development before enabling in production
7. **Monitor metrics** - Track router metrics for health and performance
8. **Validate rules** - Fix validation warnings before deploying to production

