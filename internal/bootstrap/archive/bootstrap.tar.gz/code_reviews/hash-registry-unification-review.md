# Code Review: Hash Registry Unification

**Date**: 2026-01-05  
**Reviewer**: AI Agent  
**File**: `cmd/zqk/system/check_impl.go`  
**Function**: `getHashRegistryForFile()`

## Summary

Unified hash registry loading logic to eliminate duplicate code and fix cache key mismatch between validation and auto-fix paths. The implementation successfully addresses the root cause of multiple auto-fix runs.

## Compliance Review

### ✅ Compliant Patterns

1. **Storage Provider Abstraction**: Uses `storage.HashRegistryProvider` interface, not concrete implementations
2. **Thread Safety**: Cache operations use `sync.RWMutex` correctly (RLock for reads, Lock for writes)
3. **Error Handling**: Returns nil for unknown kinds (acceptable pattern for optional resources)
4. **Function Size**: Function is appropriately sized (~50 lines, focused responsibility)
5. **Documentation**: Well-documented with clear comments explaining behavior

### ⚠️ Issues Found

#### 1. Magic String Pattern (Minor)

**Issue**: Cache key format `fmt.Sprintf("%s:%s", kind, fileDir)` is a magic string used in multiple places.

**Location**: Lines 1270, 3028, 1162, 1171

**Impact**: Low - pattern is consistent, but not maintainable if separator needs to change

**Recommendation**: Extract to a constant or helper function:
```go
const cacheKeySeparator = ":"

func formatCacheKey(kind, dir string) string {
    return fmt.Sprintf("%s%s%s", kind, cacheKeySeparator, dir)
}
```

**Priority**: Low (cosmetic improvement)

#### 2. Debug Code Anti-Pattern (Medium)

**Issue**: Debug code using `fmt.Fprintf(os.Stderr, ...)` and writing to `/tmp/zqk_debug.log` should use proper logging framework.

**Locations**: 
- Line 2891: `fmt.Fprintf(os.Stderr, "DEBUG autoFixIssues CALLED: ...")`
- Line 3104: `fmt.Fprintf(os.Stderr, ...)` with file write
- Line 3247: `fmt.Fprintf(os.Stderr, ...)` with file write
- Line 3273: `fmt.Fprintf(os.Stderr, ...)`

**Impact**: Medium - violates logging architecture pattern, pollutes stderr, creates temp files

**Recommendation**: Replace with proper logging:
```go
logger := logging.GetLoggerFromProfile(ctx.Profile)
logger.Debug("Auto-fix called",
    logging.String("object_id", obj.ID),
    logging.String("kind", kind),
    logging.String("file_path", filePath),
    logging.Int("issues_count", len(issues)))
```

**Priority**: Medium (should be fixed before production)

#### 3. Nil Return Documentation (Minor)

**Issue**: Function can return nil for unknown kinds, but documentation doesn't explicitly state this behavior.

**Location**: Line 1260

**Impact**: Low - callers handle nil correctly, but documentation could be clearer

**Recommendation**: Add explicit documentation:
```go
// Returns nil if kind is unknown or kindDir cannot be determined.
// Callers should handle nil return value gracefully.
```

**Priority**: Low (documentation improvement)

## Anti-Patterns Identified

### Anti-Pattern 1: Direct stderr/file Debug Output

**Pattern**: Using `fmt.Fprintf(os.Stderr, ...)` and writing to `/tmp/zqk_debug.log` instead of logging framework.

**Violation**: Architecture pattern requires using `pkg/logging` for all logging.

**Fix**: Replace with `logging.GetLoggerFromProfile(ctx.Profile).Debug(...)`

**Files Affected**: `check_impl.go` (multiple locations)

### Anti-Pattern 2: Magic Strings

**Pattern**: Hardcoded string format `"%s:%s"` for cache keys.

**Violation**: Code Evaluation Policy recommends extracting magic strings to constants.

**Fix**: Extract to constant or helper function.

**Files Affected**: `check_impl.go` (multiple locations)

## Recommendations

### High Priority
1. **Remove debug code**: Replace `fmt.Fprintf(os.Stderr, ...)` with proper logging
2. **Remove temp file writes**: Delete `/tmp/zqk_debug.log` writes

### Medium Priority
1. **Extract cache key format**: Create helper function or constant for cache key formatting
2. **Improve documentation**: Explicitly document nil return behavior

### Low Priority
1. **Consider context parameter**: Evaluate if function should take `ctx *clicontext.Context` instead of `projectRoot string` for consistency (current approach is acceptable for utility functions)

## Code Quality Metrics

- **Cyclomatic Complexity**: Low (simple conditional logic)
- **Function Length**: Appropriate (~50 lines)
- **Code Duplication**: Eliminated (unified function replaces 3 duplicate implementations)
- **Test Coverage**: Should be tested (not verified in this review)
- **Thread Safety**: ✅ Proper use of RWMutex
- **Error Handling**: ✅ Appropriate (nil return for optional resources)

## Conclusion

The unified function successfully addresses the root cause of multiple auto-fix runs. The implementation follows most architectural patterns correctly. The main issues are:

1. Debug code should use proper logging framework
2. Magic strings should be extracted to constants/helpers

These are relatively minor issues that don't affect functionality but should be addressed for code quality and maintainability.

