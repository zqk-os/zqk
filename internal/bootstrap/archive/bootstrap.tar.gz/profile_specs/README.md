# Profile Specifications

This directory contains versioned profile specifications that define context profiles for the zqk CLI.

## Profile Structure

Profiles define:
- **Format**: Output format (table, json, yaml)
- **Verbose**: Verbose output flag
- **Quiet**: Quiet mode flag
- **Flags**: Flag bundles automatically applied
- **Commands**: Command aliases and variants
- **Storage**: Storage context parameters (pagination, grouping)

## Available Profiles

### Base Profiles

- **`base_profile`**: Base profile that all other profiles extend
- **`ai_agent`**: Machine-readable JSON output for AI agents
- **`human`**: Human-friendly table output
- **`debug`**: YAML format with verbose logging
- **`mcp`**: MCP context with JSON output, logs to stderr
- **`pagination`**: Pagination context (max page size 5)
- **`quiet`**: Quiet profile that filters out terminal statuses

## Profile Inheritance

Profiles can extend other profiles using the `extends` field:

```yaml
schema_version: "1.0.0"
ontology: "my_profile"
extends: base_profile
format: json
```

## Usage

Profiles are applied via the `--context` flag:

```bash
zqk system status --context ai-agent
zqk object list --context quiet
```

## Schema Version

All profiles must specify a `schema_version` field (e.g., "1.0.0") for versioning and validation.

## Runtime loading (CLI)

The interactive CLI loads context profiles from `pkg/cli/profiles/` (see `paths.CLIProfilesDir` and `pkg/cli.ProfileLoader`). Files in this directory are the runtime source of truth; keep them aligned with the copies here when you change behavior so documentation and code stay consistent.

