# Profile Specifications

This directory holds **transceiver router** profiles (`type: transceiver_router`).
The scheduler loads them via `pkg/config.ProfileLoader` (default dir:
`paths.ProcessInternalProfileSpecsDir`) when starting the async router.

## Shipped router profiles

- **`base_router`**: Common knobs (worker pool, queue, timeouts). Other router profiles extend this.
- **`default_router`**: Default used at daemon start (`GetDefaultProfileName()`).
- **`high_throughput_router`**: Larger queue / more workers.
- **`low_latency_router`**: Smaller queue / tighter timeouts.

Do not put CLI context or metrics sampler YAML here. Those loaders use other directories:

- CLI `--context` profiles: `pkg/cli/profiles/` (`paths.CLIProfilesDir`)
- Metrics sampler profiles: `.zqk/metrics/profiles/` (`paths.MetricsProfilesDir`) — optional; none ship in-tree

`zqk system generate-profile-builders` reads YAML in this directory and writes
`pkg/specbuilder/bldr_profile_v1/*_builder.go`.
