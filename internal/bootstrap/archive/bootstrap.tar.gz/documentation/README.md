# Internal Documentation

**Status**: Active  
**Last Updated**: 2025-12-25

This directory contains internal system documentation that defines standards, semantics, and reference materials for the zqk system.

## Documentation Files

| Document | Category | Description |
|----------|----------|-------------|
| [Criteria Categories Definition](./criteria-categories-v1.0.md) | `criteria` | Defines standard categories for criteria objects (functional, non-functional, acceptance, test, performance, security, compliance) |
| [Query Semantics: Criteria-Based Item Filtering](./query-semantics-criteria.md) | `query` | Defines expected behavior for queries like "show me all items where non-functional criteria haven't been met yet" |

## Organization

These documents are system-level definitions that:
- Define standards and conventions
- Specify query semantics and expected behaviors
- Provide reference materials for developers and AI agents
- Support traceability and discoverability

## Related Documentation

- [Object Specs](../object_specs/README.md) - Object specifications
- [Lifecycles](../lifecycles/README.md) - Lifecycle definitions
- [Architecture Documentation](../../architecture/README.md) - Architecture design documents

