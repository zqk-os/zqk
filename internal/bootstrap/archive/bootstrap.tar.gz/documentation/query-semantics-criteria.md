# Query Semantics: Criteria-Based Item Filtering

**Version**: 1.0  
**Status**: Active  
**Last Updated**: 2025-12-25

## Query: "Show me all items where non-functional criteria haven't been met yet"

### Expected Behavior

This query should return all items (requirements, milestones, test cases, releases) that reference at least one non-functional criterion that is not yet complete or validated.

### Query Logic

1. **Find incomplete non-functional criteria**:
   - Filter criteria where `category == "non-functional"`
   - AND `status NOT IN ("complete", "validated")`
   - Statuses considered "not met": `not_started`, `in_progress`, `blocked`, `rejected`

2. **Find items referencing those criteria**:
   - **Requirements**: Items where `criteria_refs` contains any of the incomplete non-functional CRIT IDs
   - **Milestones**: Items where `criteria_refs` contains any of the incomplete non-functional CRIT IDs
   - **Test Cases**: Items where `criteria_refs` contains any of the incomplete non-functional CRIT IDs
   - **Releases**: Items where `criteria_refs` contains any of the incomplete non-functional CRIT IDs

3. **Return results**:
   - Item ID, title, kind
   - List of incomplete non-functional criteria for that item
   - Status of each incomplete criterion

### Expected Results

For each matching item, you should see:

```
REQ-018: Consistent Hash Registry Pattern Across Storage Backends
  Incomplete non-functional criteria:
    - CRIT-8204: Single registry per kind (not per-instance) [status: not_started]
    - CRIT-8205: Bulk operations are O(1) storage operations [status: in_progress]
```

### Item Types That Link to Criteria

| Item Type | Field | Required | Notes |
|-----------|-------|----------|-------|
| **Requirement** | `criteria_refs` | ✅ Yes (min 1) | All requirements must have criteria |
| **Milestone** | `criteria_refs` | ❌ Optional | Milestones can have completion criteria |
| **Test Case** | `criteria_refs` | ❌ Optional | Test cases validate criteria |
| **Release** | `criteria_refs` | ❌ Optional | Release criteria |
| **Backlog Item** | ❌ None | - | Backlog items link via requirements |

### Important Notes

1. **Backlog Items**: Do NOT directly link to criteria. They link via requirements:
   - Backlog Item → `requirement_refs` → Requirements → `criteria_refs` → Criteria
   - To find backlog items with incomplete non-functional criteria, traverse through requirements

2. **Criteria Status Values**:
   - **"not met"**: `not_started`, `in_progress`, `blocked`, `rejected`
   - **"met"**: `complete`, `validated`

3. **Bidirectional Links**:
   - Items reference criteria via `criteria_refs`
   - Criteria can also reference items via `requirement_refs`, `milestone_refs`, `backlog_item_refs`
   - Query can work in either direction, but item → criteria is primary

### Example Query Implementation

```python
# Pseudo-code
incomplete_nonfunctional_crits = [
    crit.id for crit in all_criteria 
    if crit.category == "non-functional" 
    and crit.status not in ["complete", "validated"]
]

matching_items = []
for item in all_items:
    if hasattr(item, 'criteria_refs'):
        if any(crit_id in incomplete_nonfunctional_crits 
               for crit_id in item.criteria_refs):
            matching_items.append(item)
```

### Edge Cases

1. **Item with mixed criteria**: If an item has both functional and non-functional criteria, and only non-functional are incomplete, it should still appear in results.

2. **Item with all criteria complete**: If an item references non-functional criteria but all are `complete` or `validated`, it should NOT appear.

3. **Item with no criteria**: Requirements must have criteria, but milestones/test cases/releases might not. Items without `criteria_refs` should not appear.

4. **Indirect links**: Backlog items must be found via their linked requirements.

### Related Queries

- "Show me all items where functional criteria haven't been met yet" → Same logic, `category == "functional"`
- "Show me all items where security criteria haven't been met yet" → Same logic, `category == "security"`
- "Show me all requirements with incomplete criteria" → Filter by item kind, any category
- "Show me all items blocking on criteria" → Filter criteria by `status == "blocked"`

