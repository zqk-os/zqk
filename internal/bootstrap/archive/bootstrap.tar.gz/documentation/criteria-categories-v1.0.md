# Criteria Categories Definition

**Version**: 1.0  
**Status**: Active  
**Last Updated**: 2025-12-25

## Overview

This document defines the standard categories for criteria objects in the zqk system. All criteria objects MUST specify a category to ensure traceability, discoverability, and proper classification for filtering, grouping, and reporting.

## Category Definitions

### functional

**Definition**: Criteria that validate functional requirements - what the system must do or how it must behave.

**Examples**:
- "User can create a backlog item"
- "System validates object instances against specifications"
- "File-based and graph-based backends use same hash registry pattern"
- "Spec validator checks all required checklist items for each field"

**Use When**: The criterion validates a feature, capability, or behavior that the system must provide.

**Traceability**: Links to functional requirements, feature specifications, and user stories.

---

### non-functional

**Definition**: Criteria that validate non-functional requirements - how the system performs, its quality attributes, or constraints.

**Examples**:
- "System handles 1000 concurrent users"
- "API response time is under 200ms"
- "System maintains data integrity during failures"
- "Logging system supports multiple output formats"

**Use When**: The criterion validates performance, scalability, reliability, maintainability, or other quality attributes.

**Traceability**: Links to quality requirements, performance specifications, and architectural constraints.

---

### acceptance

**Definition**: Criteria that define acceptance conditions for requirements, milestones, or deliverables.

**Examples**:
- "All unit tests pass"
- "Code review completed and approved"
- "Documentation updated"
- "Deployment successful"

**Use When**: The criterion defines what "done" means for a requirement or milestone.

**Traceability**: Links to requirements, milestones, and completion tracking.

---

### test

**Definition**: Criteria that validate test-related conditions, test coverage, or test execution results.

**Examples**:
- "Test coverage is above 80%"
- "All integration tests pass"
- "Performance tests meet thresholds"
- "Security tests pass"

**Use When**: The criterion validates testing activities, test results, or test coverage metrics.

**Traceability**: Links to test cases, test plans, and quality assurance activities.

---

### performance

**Definition**: Criteria that validate performance characteristics, response times, throughput, or resource usage.

**Examples**:
- "API endpoint responds in under 100ms"
- "System handles 10,000 requests per second"
- "Database queries complete in under 50ms"
- "Memory usage stays below 2GB"

**Use When**: The criterion validates specific performance metrics or thresholds.

**Traceability**: Links to performance requirements, load testing results, and performance benchmarks.

---

### security

**Definition**: Criteria that validate security properties, vulnerabilities, compliance, or security controls.

**Examples**:
- "No critical security vulnerabilities detected"
- "Authentication tokens expire after 1 hour"
- "Data encryption at rest enabled"
- "OWASP Top 10 vulnerabilities addressed"

**Use When**: The criterion validates security requirements, security controls, or security testing results.

**Traceability**: Links to security requirements, security audits, and compliance frameworks.

---

### compliance

**Definition**: Criteria that validate regulatory compliance, standards adherence, or policy compliance.

**Examples**:
- "GDPR compliance verified"
- "ISO 27001 controls implemented"
- "Access logs retained for 7 years"
- "Data retention policy followed"

**Use When**: The criterion validates compliance with regulations, standards, or organizational policies.

**Traceability**: Links to compliance requirements, audit reports, and regulatory frameworks.

---

## Category Selection Guidelines

1. **Primary Purpose**: Choose the category that best describes the primary purpose of the criterion.
2. **Validation Focus**: Consider what aspect is being validated (functionality, quality, testing, etc.).
3. **Traceability Needs**: Select the category that aligns with the traceability requirements.
4. **Reporting Context**: Choose the category that will be most useful for filtering and reporting.

## Category Relationships

- **functional** and **non-functional** are complementary - functional describes "what", non-functional describes "how well"
- **acceptance** criteria are often used to validate **functional** or **non-functional** requirements
- **test** criteria validate that **functional** and **non-functional** requirements are met
- **performance** is a subset of **non-functional** but has its own category for specific performance validation
- **security** and **compliance** may overlap but serve different purposes (security = protection, compliance = adherence)

## Migration Notes

For existing criteria objects without categories:
- Review the criterion's purpose and context
- Assign the most appropriate category based on the definitions above
- Update the criteria object to include the `category` field

## References

- [Criteria Object Specification](../object_specs/criteria.yaml)
- [System Ontology](../../ontology/system-ontology-v1.0.md)

